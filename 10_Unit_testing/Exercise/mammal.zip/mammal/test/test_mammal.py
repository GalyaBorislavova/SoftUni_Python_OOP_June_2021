from project.mammal import Mammal
from unittest import TestCase, main


class MammalTests(TestCase):
    def setUp(self):
        self.mammal = Mammal(name="Name", mammal_type="Type", sound="Sound")

    def test_initialize_attributes_correctly(self):
        self.assertEqual("Name", self.mammal.name)
        self.assertEqual("Type", self.mammal.type)
        self.assertEqual("Sound", self.mammal.sound)
        self.assertEqual("animals", self.mammal._Mammal__kingdom)

    def test_make_sound_method(self):
        self.assertEqual("Name makes Sound", self.mammal.make_sound())

    def test_get_kingdom_method(self):
        self.assertEqual("animals", self.mammal.get_kingdom())

    def test_info_method(self):
        self.assertEqual("Name is of type Type", self.mammal.info())


if __name__ == "__main__":
    main()
